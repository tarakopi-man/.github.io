CREATE TABLE `blog_settings` (
	`id` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL
);
