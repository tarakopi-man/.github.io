export type BlogSettings = {
 title:string;description:string;author:string;profile:string;about:string;footer:string;
 categories:string[];background:string;linkColor:string;accentColor:string;fontSize:number;width:number;
};
export const defaults:BlogSettings={title:'とりあえず雑記帳',description:'特にテーマはありません。気が向いたら更新します。',author:'管理人',profile:'好きなものとか、\nどうでもいい話とか。\nだいたい雑記です。',about:'日記とか、好きなものの話とか、ちょっとしたメモとかを書きます。\n\n更新は気が向いたときに。内容もだいたい適当です。',footer:'気が向いたら更新します。',categories:['日記','好きなもの','メモ'],background:'#ededed',linkColor:'#0000cc',accentColor:'#8899bb',fontSize:13,width:820};
export function parseSettings(input:unknown):BlogSettings{
 if(!input||typeof input!=='object'||Array.isArray(input))throw Error('設定の形式が正しくありません。');
 const p=input as Record<string,unknown>;
 const s={...defaults} as BlogSettings;
 for(const [key,max] of [['title',100],['description',500],['author',100],['profile',3000],['about',20000],['footer',500]] as const){if(typeof p[key]!=='string'||p[key].length>max)throw Error('設定の文章が長すぎるか、形式が正しくありません。');s[key]=p[key];}
 if(!s.title.trim())throw Error('サイト名を入力してください。');
 if(!Array.isArray(p.categories)||p.categories.length<1||p.categories.length>20||p.categories.some(c=>typeof c!=='string'||!c.trim()||c.length>30||c==='すべて'))throw Error('カテゴリは1〜20個、各30文字以内で入力してください。「すべて」は使えません。');
 s.categories=[...new Set((p.categories as string[]).map(c=>c.trim()))];
 for(const key of ['background','linkColor','accentColor'] as const){if(typeof p[key]!=='string'||!/^#[0-9a-f]{6}$/i.test(p[key]))throw Error('色の指定が正しくありません。');s[key]=p[key];}
 if(!Number.isInteger(p.fontSize)||Number(p.fontSize)<11||Number(p.fontSize)>20||!Number.isInteger(p.width)||Number(p.width)<640||Number(p.width)>1200)throw Error('文字サイズは11〜20、横幅は640〜1200で指定してください。');
 s.fontSize=Number(p.fontSize);s.width=Number(p.width);return s;
}
export type BackupPost={id:string;title:string;body:string;category:string;status:string;created_at:string;updated_at:string};
export type BlogBackup={format:'personal-blog-backup';version:1;exportedAt:string;settings:BlogSettings;posts:BackupPost[]};
export function parseBackup(input:unknown):BlogBackup{
 if(!input||typeof input!=='object')throw Error('バックアップの形式が正しくありません。');
 const b=input as Record<string,unknown>;
 if(b.format!=='personal-blog-backup'||b.version!==1||!Array.isArray(b.posts)||b.posts.length>5000)throw Error('このブログのバックアップJSONを選択してください（最大5,000記事）。');
 const settings=parseSettings(b.settings),seen=new Set<string>();
 const posts=b.posts.map((p:Record<string,unknown>)=>{
 if(!p||typeof p!=='object'||typeof p.id!=='string'||!/^[a-zA-Z0-9_-]{1,80}$/.test(p.id)||seen.has(p.id)||typeof p.title!=='string'||!p.title.trim()||p.title.length>150||typeof p.body!=='string'||p.body.length>100000||typeof p.category!=='string'||!p.category.trim()||p.category==='すべて'||p.category.length>30||typeof p.status!=='string'||!['draft','published','trash'].includes(p.status)||typeof p.created_at!=='string'||!Number.isFinite(Date.parse(p.created_at))||typeof p.updated_at!=='string'||!Number.isFinite(Date.parse(p.updated_at)))throw Error('記事データに不正な値や重複IDがあります。復元は行いませんでした。');
 seen.add(p.id);return {id:p.id,title:p.title,body:p.body,category:p.category,status:p.status,created_at:p.created_at,updated_at:p.updated_at} as BackupPost;
 });
 return {format:'personal-blog-backup',version:1,exportedAt:typeof b.exportedAt==='string'?b.exportedAt:'',settings,posts};
}
