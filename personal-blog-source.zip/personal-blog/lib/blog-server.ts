import {env} from 'cloudflare:workers';
import {defaults,parseSettings,type BlogSettings} from './blog-config';
export const reply=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export function sameOrigin(request:Request){return request.headers.get('origin')===new URL(request.url).origin;}
export async function isOwner(request:Request,claim=false){
 const uid=request.headers.get('oai-authenticated-user-id');if(!uid)return false;
 // Initial claim is protected by this Site's owner-private access policy.
 if(claim)await env.DB!.prepare('INSERT OR IGNORE INTO blog_owner (id,user_id) VALUES (?,?)').bind('owner',uid).run();
 const owner=await env.DB!.prepare('SELECT user_id FROM blog_owner WHERE id=?').bind('owner').first<{user_id:string}>();
 return owner?.user_id===uid;
}
export async function getSettings():Promise<BlogSettings>{
 const row=await env.DB!.prepare('SELECT value FROM blog_settings WHERE id=?').bind('main').first<{value:string}>();
 return row?parseSettings(JSON.parse(row.value)):{...defaults};
}
export function settingsStatement(settings:BlogSettings){return env.DB!.prepare('INSERT INTO blog_settings (id,value) VALUES (?,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value').bind('main',JSON.stringify(settings));}
