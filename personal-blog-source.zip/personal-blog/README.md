# 個人ブログのソース

平成のシンプルな個人ブログ風の、記事投稿・下書き・サイト設定・バックアップ機能付きブログです。

## 普段の使い方

ブログをブラウザで開き、管理用メニューを使います。

- 「記事を書く」: タイトル・本文・カテゴリを入力し、下書き保存または公開済みにします。
- 「設定・バックアップ」: サイト名、説明文、管理人名、自己紹介、サイトについての本文、フッター、カテゴリ、背景色・リンク色・上部の線の色、文字サイズ、PCの横幅を変えられます。
- 設定は「設定を保存」を押すとサイト側に保存され、ほかのPCや記事の固定リンクにも反映されます。
- サイトの公開範囲は、記事や設定の保存では変わりません。閲覧範囲はホスティング側の設定です。

## 手元に残すもの

1. このソースZIP: デザインとプログラムです。
2. 管理画面で保存するバックアップJSON: 公開記事、下書き、ゴミ箱の記事、保存済みのサイト設定です。

両方を保存してください。ZIPには実際の記事や保存済みのサイト設定、ログイン情報は含めません。PC内だけに残っている書きかけは、先に「下書き保存」してください。

復元は「設定・バックアップ」でJSONを選び、件数を確認して実行します。既存の記事は削除しません。初期状態では同じIDの記事を変更しません。「同じIDの記事を上書きする」を選ぶとバックアップの内容に更新します。保存時刻や公開・下書きの状態も復元します。サイト設定も復元するか選べます。最大10MB・5,000記事のファイルに対応します。

## ファイルを直接編集する場合

- app/blog.tsx: トップページ・記事一覧・投稿画面
- app/settings-panel.tsx: 設定とバックアップ画面
- app/globals.css: 見た目
- lib/blog-config.ts: 初期値とバックアップのデータ形式
- app/posts/[id]/page.tsx: 個別記事のページ
- app/api/: 保存・設定・バックアップのAPI
- db/schema.ts と drizzle/: データベースの構造・変更履歴

通常のサイト名や色は管理画面から変えてください。保存済みの設定があれば、コードの初期値よりそちらが優先されます。

## PCで開発用に動かす

ZIPを展開しただけでは動きません。Node.js 22.13以降とnpmが必要です。PowerShellやターミナルで、このフォルダを開いて実行します。

    npm ci
    npm run build

次に、同梱したdrizzleフォルダ内のSQLをファイル番号順にローカルDBに適用します。各ファイルについて次のコマンドを実行します（末尾のファイル名を実際のものに置き換えます）。

    node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_robust_charles_xavier.sql
    node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_careless_lockjaw.sql
    npm run dev

表示されたlocalhostのURLを開きます。「管理者ログイン」から、開発用のローカルアカウントで入れます。ローカルDBと公開サイトのDBは別物です。必要ならバックアップJSONを管理画面から読み込んでください。

変更を確認したら `npm run build` でビルドします。ソースZIPもpublic/blog-source.zipに更新されます。ZIP内にはGitの履歴は含めません。

## 別の場所で公開する場合

このプログラムはVinext/React + Cloudflare Workers/D1を使います。HTMLファイルだけを置く静的レンタルサーバーでは、投稿や保存は動きません。

同梱の.openai/hosting.jsonでは、元のサイトの識別子を取り除いています。Sitesで新しいサイトとして登録し、D1のDBバインディングを接続してデプロイする必要があります。新しいサイトはまず所有者だけが見られる状態にし、所有者が最初の設定保存または記事保存を行って管理者登録を済ませ、その後JSONを復元してください。

Sites以外に移す場合は、D1の接続先と認証の実装が必要です。現在の認証はSitesが検証・注入するoai-authenticated-user-idを前提とします。別のホストでそのヘッダーを単純に信用すると、管理画面を保護できません。公開前にホストに合ったログイン処理に置き換えてください。
