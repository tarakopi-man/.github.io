import { sqliteTable, text } from 'drizzle-orm/sqlite-core';
export const posts = sqliteTable('posts', {
 id: text('id').primaryKey(), title: text('title').notNull(), body: text('body').notNull(),
 category: text('category').notNull(), status: text('status').notNull(),
 createdAt: text('created_at').notNull(), updatedAt: text('updated_at').notNull(),
});
export const blogOwner = sqliteTable('blog_owner', { id: text('id').primaryKey(), userId: text('user_id').notNull() });
export const blogSettings = sqliteTable('blog_settings', { id: text('id').primaryKey(), value: text('value').notNull() });
