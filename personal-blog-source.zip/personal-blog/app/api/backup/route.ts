import {env} from 'cloudflare:workers';
import {getSettings,isOwner,reply,sameOrigin,settingsStatement} from '../../../lib/blog-server';
import {parseBackup} from '../../../lib/blog-config';
export const dynamic='force-dynamic';
export async function GET(request:Request){
 try{
 if(!await isOwner(request)){
 const empty=!await env.DB!.prepare('SELECT id FROM blog_owner LIMIT 1').first();
 if(!empty||!request.headers.get('oai-authenticated-user-id'))return reply({error:'管理者だけがバックアップできます。'},403);
 }
 const posts=await env.DB!.prepare('SELECT * FROM posts ORDER BY created_at DESC').all();
 const data={format:'personal-blog-backup',version:1,exportedAt:new Date().toISOString(),settings:await getSettings(),posts:posts.results};
 return new Response(JSON.stringify(data,null,2),{headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Content-Disposition':`attachment; filename="blog-backup-${new Date().toISOString().slice(0,10)}.json"`,'X-Content-Type-Options':'nosniff'}});
 }catch{return reply({error:'バックアップを作成できませんでした。'},500);}
}
export async function POST(request:Request){
 try{
 if(!sameOrigin(request))return reply({error:'この操作は許可されていません。'},403);
 if(!request.headers.get('oai-authenticated-user-id'))return reply({error:'ログインしてください。'},401);
 if(Number(request.headers.get('content-length')||0)>10000000)return reply({error:'復元できるファイルは10MBまでです。'},413);
 const raw=await request.text();if(new TextEncoder().encode(raw).length>10000000)return reply({error:'復元できるファイルは10MBまでです。'},413);
 let input,backup;try{input=JSON.parse(raw);backup=parseBackup(input.backup);if(typeof input.overwrite!=='boolean'||typeof input.applySettings!=='boolean')throw Error('復元の指定が正しくありません。');}catch(e){return reply({error:e instanceof Error?e.message:'ファイルを確認してください。'},400);}
 if(!await isOwner(request,true))return reply({error:'管理者だけが復元できます。'},403);
 const statements=backup.posts.map(p=>env.DB!.prepare('INSERT INTO posts (id,title,body,category,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?) ON CONFLICT(id) '+(input.overwrite?'DO UPDATE SET title=excluded.title,body=excluded.body,category=excluded.category,status=excluded.status,created_at=excluded.created_at,updated_at=excluded.updated_at':'DO NOTHING')).bind(p.id,p.title,p.body,p.category,p.status,p.created_at,p.updated_at));
 if(input.applySettings)statements.push(settingsStatement(backup.settings));
 // D1 batch is transactional: either the whole validated backup is applied or none of it.
 const result=statements.length?await env.DB!.batch(statements):[];
 const changed=result.slice(0,backup.posts.length).reduce((n,r)=>n+(r.meta.changes||0),0);
 return reply({changed,skipped:backup.posts.length-changed,settingsApplied:input.applySettings});
 }catch{return reply({error:'復元できませんでした。データを確認して再度お試しください。'},500);}
}
