import { env } from 'cloudflare:workers';
import {isOwner as owner} from '../../../lib/blog-server';
export const dynamic = 'force-dynamic';
const reply = (data: unknown, status=200) => Response.json(data, {status, headers:{'Cache-Control':'no-store'}});

export async function GET(request: Request) {
 try {
 const isOwner=await owner(request);
 const rows=await env.DB!.prepare(isOwner?'SELECT * FROM posts ORDER BY updated_at DESC':"SELECT * FROM posts WHERE status='published' ORDER BY created_at DESC").all();
 return reply({posts:rows.results,canEdit:isOwner,canStart:!await env.DB!.prepare('SELECT id FROM blog_owner LIMIT 1').first() && !!request.headers.get('oai-authenticated-user-id')});
 } catch {return reply({error:'記事を読み込めませんでした。時間をおいて再読み込みしてください。'},503);}
}
export async function POST(request: Request) {
 try {
 if(request.headers.get('origin')!==new URL(request.url).origin) return reply({error:'この操作は許可されていません。'},403);
 if(!request.headers.get('oai-authenticated-user-id'))return reply({error:'記事を書くにはログインしてください。'},401);
 if(Number(request.headers.get('content-length')||0)>250000) return reply({error:'本文が長すぎます。'},413);
 const input=await request.text(); if(input.length>200000)return reply({error:'本文が長すぎます。'},413);
 const p=JSON.parse(input);
 if(typeof p.title!=='string'||!p.title.trim()||p.title.length>150||typeof p.body!=='string'||p.body.length>100000||!['draft','published','trash'].includes(p.status)||(typeof p.category!=='string'||!p.category.trim()||p.category==='すべて'||p.category.length>30))return reply({error:'タイトルと本文、カテゴリを確認してください。'},400);
 if(!await owner(request,true))return reply({error:'投稿できるのはこのブログの管理者だけです。'},403);
 const id=p.id||crypto.randomUUID(); if(typeof id!=='string'||id.length>80)return reply({error:'記事IDが正しくありません。'},400);
 const now=new Date().toISOString();
 await env.DB!.prepare('INSERT INTO posts (id,title,body,category,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,body=excluded.body,category=excluded.category,status=excluded.status,updated_at=excluded.updated_at').bind(id,p.title.trim(),p.body,p.category,p.status,now,now).run();
 return reply({id});
 } catch {return reply({error:'保存できませんでした。入力内容はこのPCに残っています。もう一度お試しください。'},500);}
}


