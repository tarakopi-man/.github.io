import {getSettings,isOwner,reply,sameOrigin,settingsStatement} from '../../../lib/blog-server';
import {parseSettings} from '../../../lib/blog-config';
export const dynamic='force-dynamic';
export async function GET(){try{return reply({settings:await getSettings()});}catch{return reply({error:'設定を読み込めませんでした。'},503);}}
export async function POST(request:Request){
 try{
 if(!sameOrigin(request))return reply({error:'この操作は許可されていません。'},403);
 if(!request.headers.get('oai-authenticated-user-id'))return reply({error:'ログインしてください。'},401);
 const text=await request.text();if(text.length>40000)return reply({error:'設定のデータが大きすぎます。'},413);
 let settings;try{settings=parseSettings(JSON.parse(text));}catch(e){return reply({error:e instanceof Error?e.message:'設定を確認してください。'},400);}
 if(!await isOwner(request,true))return reply({error:'管理者だけが設定を変更できます。'},403);
 await settingsStatement(settings).run();return reply({settings});
 }catch{return reply({error:'設定を保存できませんでした。再度お試しください。'},500);}
}
