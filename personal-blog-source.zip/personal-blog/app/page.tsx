import Blog from './blog';
import {getSettings} from '../lib/blog-server';
export const dynamic='force-dynamic';
export default async function Home() { return <Blog initialSettings={await getSettings()} />; }
