import {env} from 'cloudflare:workers';
import {headers} from 'next/headers';
import {notFound} from 'next/navigation';
import {getSettings} from '../../../lib/blog-server';
export const dynamic='force-dynamic';
async function load(id:string){
 const row=await env.DB!.prepare('SELECT * FROM posts WHERE id=?').bind(id).first<{id:string;title:string;body:string;category:string;status:string;created_at:string}>();
 if(!row||row.status==='trash')return null;
 if(row.status==='published')return row;
 const uid=(await headers()).get('oai-authenticated-user-id');
 const owner=await env.DB!.prepare('SELECT user_id FROM blog_owner WHERE id=?').bind('owner').first<{user_id:string}>();
 return uid&&uid===owner?.user_id?row:null;
}
export async function generateMetadata({params}:{params:Promise<{id:string}>}){const p=await load((await params).id),s=await getSettings();return {title:p?`${p.title} | ${s.title}`:`記事が見つかりません | ${s.title}`,description:p?.status==='published'?p.body.slice(0,120):undefined,robots:p?.status==='published'?undefined:{index:false,follow:false}};}
export default async function Article({params}:{params:Promise<{id:string}>}){
 const p=await load((await params).id);if(!p)notFound();const settings=await getSettings();
 return <main className="standalone"><header className="site-header"><h1><a href="/">{settings.title}</a></h1><p>{settings.description}</p></header><div className="article-wrap"><a href="/">≪ 記事一覧に戻る</a><article className="entry"><div className="entry-date"><time>{new Date(p.created_at).toLocaleDateString('ja-JP',{timeZone:'Asia/Tokyo'})}</time> / {p.category}{p.status==='draft'&&' / 下書き'}</div><h2>{p.title}</h2><div className="prose">{p.body.split('\n\n').map((part,i)=>part.startsWith('## ')?<h2 key={i}>{part.slice(3)}</h2>:<p key={i}>{part}</p>)}</div><div className="entry-bottom"><a href={`/#${p.id}`}>ブログに戻る</a></div></article></div><footer><a href="/">{settings.title}</a><br/><small>{settings.footer}</small></footer></main>;
}

