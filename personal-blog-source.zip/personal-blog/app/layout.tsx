import type { Metadata } from "next";
import "./globals.css";
import {getSettings} from '../lib/blog-server';
import type {CSSProperties} from 'react';
export const dynamic='force-dynamic';

export async function generateMetadata():Promise<Metadata> { const s=await getSettings();return {
  title: s.title,
  description: s.description,
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
}; }

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const s=await getSettings();
  return (
    <html lang="ja">
      <body style={{'--blog-bg':s.background,'--blog-link':s.linkColor,'--blog-accent':s.accentColor,'--blog-size':`${s.fontSize}px`,'--blog-width':`${s.width}px`} as CSSProperties}>{children}</body>
    </html>
  );
}

