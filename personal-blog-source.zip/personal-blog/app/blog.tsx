'use client';
import {useEffect,useState} from 'react';
import {defaults,type BlogSettings} from '../lib/blog-config';
import SettingsPanel from './settings-panel';
type Post={id:string;title:string;body:string;category:string;status:string;created_at:string;updated_at:string};
const blank=():Post=>({id:'',title:'',body:'',category:'日記',status:'draft',created_at:'',updated_at:''});
const samples:Post[]=[
 {id:'sample-1',title:'ブログをつくった',body:'※表示確認用のサンプル記事です。\n\nとりあえずブログをつくってみた。\n何を書くかはまだ決めてないけど、日記とかメモとか適当に置いていく予定。\n\n三日坊主にならない程度にやります。',category:'日記',status:'published',created_at:'2026-11-03',updated_at:'2026-11-03'},
 {id:'sample-2',title:'最近のこと',body:'※表示確認用のサンプル記事です。\n\n気づいたらもう11月。\n最近は家でだらだらしていることが多い。\n\n書くことないので今日はここまで。',category:'日記',status:'published',created_at:'2026-11-02',updated_at:'2026-11-02'},
 {id:'sample-3',title:'メモ',body:'※表示確認用のサンプル記事です。\n\n・読みかけの本\n・気になってた映画\n・あとで調べること\n\n忘れるのでここに書いておく。',category:'メモ',status:'published',created_at:'2026-11-01',updated_at:'2026-11-01'}
];
function Text({body}:{body:string}){return <div className="prose">{body.split('\n\n').map((p,i)=>p.startsWith('## ')?<h2 key={i}>{p.slice(3)}</h2>:<p key={i}>{p}</p>)}</div>}
const date=(s:string)=>s?new Date(s).toLocaleDateString('ja-JP',{year:'numeric',month:'2-digit',day:'2-digit',timeZone:'Asia/Tokyo'}).replaceAll('/','.'):'';
export default function Blog({initialSettings=defaults}:{initialSettings?:BlogSettings}){
 const [config,setConfig]=useState(initialSettings);
 const [posts,setPosts]=useState<Post[]>([]),[allowed,setAllowed]=useState(false),[loading,setLoading]=useState(true),[error,setError]=useState('');
 const [category,setCategory]=useState('すべて'),[query,setQuery]=useState(''),[view,setView]=useState('home'),[selected,setSelected]=useState<Post|null>(null);
 const [editor,setEditor]=useState<Post|null>(null),[preview,setPreview]=useState(false),[busy,setBusy]=useState(false),[notice,setNotice]=useState(''),[backup,setBackup]=useState<Post|null>(null);
 async function reload(){try{const [r,sr]=await Promise.all([fetch('/api/posts'),fetch('/api/settings')]);const data=await r.json() as {error?:string;posts:Post[];canEdit:boolean;canStart:boolean};const sd=await sr.json() as {error?:string;settings:BlogSettings};if(!r.ok||!sr.ok)throw Error(data.error||sd.error||'読み込めませんでした。');setPosts(data.posts);setConfig(sd.settings);setAllowed(data.canEdit||data.canStart);setError('');}catch(e){setError(e instanceof Error?e.message:'読み込みに失敗しました。');}finally{setLoading(false);}}
 useEffect(()=>{document.title=config.title;for(const [k,v] of Object.entries({'--blog-bg':config.background,'--blog-link':config.linkColor,'--blog-accent':config.accentColor,'--blog-size':`${config.fontSize}px`,'--blog-width':`${config.width}px`}))document.body.style.setProperty(k,v);},[config]);
 useEffect(()=>{void reload();try{const saved=localStorage.getItem('yohaku-draft');if(saved)setBackup(JSON.parse(saved));}catch{}},[]);
 useEffect(()=>{if(loading)return;function openHash(){const id=decodeURIComponent(location.hash.slice(1));if(id){const p=[...posts,...samples].find(p=>p.id===id&&p.status!=='trash');if(p)setSelected(p);}else setSelected(null);}openHash();window.addEventListener('hashchange',openHash);return()=>window.removeEventListener('hashchange',openHash);},[loading,posts]);
 useEffect(()=>{if(!editor)return;try{localStorage.setItem('yohaku-draft',JSON.stringify(editor));}catch{}},[editor]);
 useEffect(()=>{function esc(e:KeyboardEvent){if(e.key==='Escape'){if(editor){closeEditor();}else{setSelected(null);setView('home');}}}window.addEventListener('keydown',esc);return()=>window.removeEventListener('keydown',esc);},[editor]);
 function closeEditor(){if(editor&&(editor.title||editor.body))setBackup(editor);setEditor(null);setPreview(false);}
 function edit(post?:Post){setEditor(post?{...post}:{...blank(),category:config.categories[0]});setPreview(false);setNotice('');}
 async function save(status:string){if(!editor||busy)return;if(!editor.title.trim()){setNotice('タイトルを入力してください。');return;}setBusy(true);setNotice('');try{const r=await fetch('/api/posts',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...editor,status})});const result=await r.json() as {error?:string;id:string};if(!r.ok)throw Error(result.error);setEditor(null);setBackup(null);try{localStorage.removeItem('yohaku-draft');}catch{}setSelected(null);setNotice(status==='published'?'記事を公開済みにしました。':status==='trash'?'記事をゴミ箱に移しました。':'下書きを保存しました。');await reload();}catch(e){setNotice(e instanceof Error?e.message:'保存できませんでした。');}finally{setBusy(false);}}
 const real=posts.filter(p=>p.status==='published');
 const showingSamples=!loading&&!error&&!real.length&&view==='home';
 const source=view==='drafts'?posts.filter(p=>p.status==='draft'):view==='trash'?posts.filter(p=>p.status==='trash'):real.length?real:showingSamples?samples:[];
 const visible=source.filter(p=>(category==='すべて'||p.category===category)&&(!query||(p.title+' '+p.body).toLowerCase().includes(query.toLowerCase())));
 const categories=[...new Set([...config.categories,...posts.map(p=>p.category)])];
 const navigate=(next:string)=>{setView(next);setCategory('すべて');setQuery('');setSelected(null);history.replaceState(null,'','/');window.scrollTo(0,0);};
 return <div className="site">
  <header className="site-header"><h1><a href="/">{config.title}</a></h1><p>{config.description}</p><div className="header-note">個人ブログ / since 2026.11</div></header>
  <nav className="top-nav" aria-label="サイト内メニュー"><button onClick={()=>navigate('home')}>［ トップ ］</button><button onClick={()=>navigate('about')}>［ このサイトについて ］</button>{allowed&&<button onClick={()=>edit()}>［ 記事を書く ］</button>}</nav>
  <div className="columns"><aside className="sidebar">
   <section><h2>メニュー</h2><ul><li><button className={view==='home'?'current':''} onClick={()=>navigate('home')}>最近の記事 ({real.length})</button></li><li><button onClick={()=>navigate('about')}>このサイトについて</button></li></ul></section>
   <section><h2>カテゴリ</h2><ul>{['すべて',...categories].map(c=><li key={c}><button className={category===c?'current':''} onClick={()=>{setCategory(c);setView('home');setSelected(null);}}>{c}</button></li>)}</ul></section>
   <section><h2>記事検索</h2><label><span className="sr-only">記事を検索</span><input className="search-input" value={query} onChange={e=>{setQuery(e.target.value);setSelected(null);}} placeholder="キーワード" /></label><small>入力すると絞り込みます。</small></section>
   <section><h2>{config.author||'管理人'}</h2><p className="profile-text">{config.profile}</p></section>
   <section><h2>管理用</h2>{allowed?<ul><li><button onClick={()=>edit()}>記事を書く</button></li><li><button onClick={()=>navigate('drafts')}>下書き ({posts.filter(p=>p.status==='draft').length})</button></li><li><button onClick={()=>navigate('settings')}>設定・バックアップ</button></li><li><button onClick={()=>navigate('trash')}>ゴミ箱 ({posts.filter(p=>p.status==='trash').length})</button></li></ul>:!loading&&!error?<a href="/signin-with-chatgpt?return_to=%2F" target="_top">管理者ログイン</a>:<p>読み込み中...</p>}</section>
  </aside>
  <main className="entries">
   {notice&&!editor&&<p className="message" role="status">{notice}</p>}
   {error&&<p className="message error" role="alert">{error} <button onClick={()=>void reload()}>再読み込み</button></p>}
   {backup&&allowed&&!editor&&<p className="message">書きかけの記事があります。<button onClick={()=>edit(backup)}>続きを書く</button> / <button onClick={()=>{if(confirm('PC内の書きかけを破棄しますか？')){setBackup(null);localStorage.removeItem('yohaku-draft');}}}>破棄</button></p>}
   {view==='settings'&&allowed?<SettingsPanel settings={config} posts={posts} onSaved={setConfig} onRestored={reload}/>:view==='about'?<article><h2 className="page-heading">このサイトについて</h2><Text body={config.about}/><p><button onClick={()=>navigate('home')}>トップに戻る</button></p></article>:selected?<article className="entry"><p><button onClick={()=>{setSelected(null);history.replaceState(null,'','/');}}>≪ 記事一覧に戻る</button></p><div className="entry-date">{date(selected.created_at)}　{selected.category}{selected.id.startsWith('sample-')&&' / サンプル'}</div><h2>{selected.title}</h2><Text body={selected.body}/><div className="entry-bottom">{!selected.id.startsWith('sample-')&&<a href={`/posts/${selected.id}`}>この記事のURL</a>}{allowed&&!selected.id.startsWith('sample-')&&<> | <button onClick={()=>edit(selected)}>編集</button></>}</div></article>:<>
    <h2 className="page-heading">{view==='drafts'?'下書き':view==='trash'?'ゴミ箱':category==='すべて'?'最近の記事':category}</h2>
    {showingSamples&&<p className="sample-note">※以下は表示確認用のサンプルです。最初の記事を公開すると置き換わります。</p>}
    {loading?<p>読み込み中...</p>:!visible.length?<p>{query?'該当する記事はありません。':'まだ記事はありません。'} {allowed&&<button onClick={()=>edit()}>記事を書く</button>}</p>:visible.map(p=><article className="entry" key={p.id}><div className="entry-date">{date(p.created_at)} ({['日','月','火','水','木','金','土'][new Date(p.created_at).getDay()]})</div><h2><button onClick={()=>{setSelected(p);history.replaceState(null,'',`/#${p.id}`);}}>{p.title}</button></h2><Text body={p.body}/><div className="entry-bottom">カテゴリ：<button onClick={()=>setCategory(p.category)}>{p.category}</button> | <button onClick={()=>{setSelected(p);history.replaceState(null,'',`/#${p.id}`);}}>記事を開く</button>{allowed&&!p.id.startsWith('sample-')&&<> | <button onClick={()=>edit(p)}>編集</button></>}</div></article>)}
   </>}
  </main></div>
  <footer><a href="/">{config.title}</a><br/><small>{config.footer}</small></footer>
  {editor&&<div className="editor-backdrop"><section className="editor" role="dialog" aria-modal="true" aria-label="記事を書く"><header><h2>記事を書く</h2><button className="close" aria-label="閉じる" onClick={closeEditor}>閉じる ×</button></header><div className="editor-controls"><label>カテゴリ：<select disabled={busy} value={editor.category} onChange={e=>setEditor({...editor,category:e.target.value})}>{[...new Set([...categories,editor.category])].map(c=><option key={c}>{c}</option>)}</select></label><button onClick={()=>setPreview(!preview)}>{preview?'編集に戻る':'プレビュー'}</button></div>{preview?<div className="editor-preview"><h2>{editor.title||'タイトル未入力'}</h2><Text body={editor.body||'本文未入力'}/></div>:<><label className="field-label" htmlFor="title">タイトル</label><input id="title" autoFocus disabled={busy} className="title-input" maxLength={150} value={editor.title} onChange={e=>setEditor({...editor,title:e.target.value})}/><label className="field-label" htmlFor="body">本文</label><textarea id="body" disabled={busy} maxLength={100000} placeholder={'ここに本文。\n\n「## 見出し」で小見出しが作れます。'} value={editor.body} onChange={e=>setEditor({...editor,body:e.target.value})}/></>}<p className="editor-hint">{editor.body.length.toLocaleString()}文字 / 書きかけはPC内にも一時保存されます。</p>{notice&&<p className="message" role="status">{notice}</p>}<div className="savebar">{editor.id&&<button disabled={busy} onClick={()=>{if(confirm('記事をゴミ箱に移しますか？あとから戻せます。'))void save('trash');}}>ゴミ箱へ</button>}<span/><button className="native-button" disabled={busy} onClick={()=>void save('draft')}>{busy?'保存中...':'下書き保存'}</button><button className="native-button" disabled={busy} onClick={()=>void save('published')}>{busy?'保存中...':'公開済みにする'}</button></div><p className="publish-note">サイトの閲覧範囲は変わりません。現在の共有設定の範囲で読めます。</p></section></div>}
 </div>;
}


