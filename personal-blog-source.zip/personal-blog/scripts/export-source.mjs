// Dependency-free ZIP exporter. Includes authored source, never runtime data or credentials.
import {execFileSync} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync,existsSync,readdirSync} from 'node:fs';
import {deflateRawSync} from 'node:zlib';
const excluded=new Set(['.git','.sites-runtime','.wrangler','.vinext','.next','node_modules','dist','outputs','work','.agents','.codex']);
function walk(dir=''){return readdirSync(dir||'.',{withFileTypes:true}).flatMap(e=>{if(excluded.has(e.name)||e.name.startsWith('.env')||e.name.startsWith('.dev.vars')||e.isSymbolicLink())return [];const file=(dir?dir+'/':'')+e.name;return e.isDirectory()?walk(file):[file];});}
const files=[...new Set(existsSync('.git')?execFileSync('git',['ls-files','-z','--cached','--others','--exclude-standard'],{encoding:'utf8'}).split('\0').filter(Boolean):walk())].sort();
const table=Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
function crc32(bytes){let n=0xffffffff;for(const b of bytes)n=table[(n^b)&255]^(n>>>8);return(n^0xffffffff)>>>0;}
const chunks=[],directory=[];let offset=0;
for(const file of files){
 if(file==='public/blog-source.zip'||file.startsWith('.git/')||file.startsWith('.sites-runtime/')||file.startsWith('.wrangler/')||file.startsWith('outputs/')||file.startsWith('node_modules/')||file.startsWith('dist/')||/(^|\/)\.env|(^|\/)\.dev\.vars/.test(file))continue;
 let bytes=readFileSync(file);
 if(file==='.openai/hosting.json'){const m=JSON.parse(bytes.toString());delete m.project_id;bytes=Buffer.from(JSON.stringify(m,null,2)+'\n');}
 const name=Buffer.from('personal-blog/'+file),data=deflateRawSync(bytes),crc=crc32(bytes),header=Buffer.alloc(30);
 header.writeUInt32LE(0x04034b50,0);header.writeUInt16LE(20,4);header.writeUInt16LE(0x800,6);header.writeUInt16LE(8,8);header.writeUInt16LE(33,12);header.writeUInt32LE(crc,14);header.writeUInt32LE(data.length,18);header.writeUInt32LE(bytes.length,22);header.writeUInt16LE(name.length,26);
 chunks.push(header,name,data);const central=Buffer.alloc(46);
 central.writeUInt32LE(0x02014b50,0);central.writeUInt16LE(20,4);central.writeUInt16LE(20,6);central.writeUInt16LE(0x800,8);central.writeUInt16LE(8,10);central.writeUInt16LE(33,14);central.writeUInt32LE(crc,16);central.writeUInt32LE(data.length,20);central.writeUInt32LE(bytes.length,24);central.writeUInt16LE(name.length,28);central.writeUInt32LE(offset,42);
 directory.push(central,name);offset+=header.length+name.length+data.length;
}
const dir=Buffer.concat(directory),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(directory.length/2,8);end.writeUInt16LE(directory.length/2,10);end.writeUInt32LE(dir.length,12);end.writeUInt32LE(offset,16);
mkdirSync('public',{recursive:true});writeFileSync('public/blog-source.zip',Buffer.concat([...chunks,dir,end]));
console.log(`Source ZIP ready (${directory.length/2} files). Posts and runtime settings are exported separately as JSON.`);
